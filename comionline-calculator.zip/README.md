
# ComiOnline - Calculadora de Crédito (Plantilla)

Proyecto plantilla para una **calculadora de crédito** inspirada en la estética de ComiOnline.
Incluye:
- Backend Node/Express con endpoints:
  - `POST /api/calculate` -> devuelve el pago mensual, interés total y tabla de amortización.
  - `POST /api/schedule-csv` -> descarga CSV con la tabla de amortización.
  - `POST /api/generate-ticket` -> devuelve un DataURL con el QR del ticket.
- Frontend estático (Tailwind CDN) listo para subir a GitHub Pages o servir junto al backend.

## Estructura
- `backend/` - servidor Express (puerto 3000 por defecto)
- `frontend/` - página estática `index.html`

## Instrucciones locales
1. Backend:
   ```bash
   cd backend
   npm install
   npm start
   ```
2. Frontend:
   - Abrir `frontend/index.html` en el navegador.
   - Si sirves backend local, abre `frontend/index.html` con `Live Server` o coloca ambos en un mismo host.

## Despliegue en GitHub + Zeabur
1. Subir este repositorio a GitHub (rama principal).
2. En Zeabur crea un nuevo servicio:
   - Selecciona **Node** y apunta al `backend` folder (o usa `package.json` at root si lo configuras así).
   - Configura `PORT` si es necesario (Zeabur gestiona automáticamente).
   - Para servir frontend desde el mismo servicio, puedes usar a) servir archivos estáticos con `express.static` o b) desplegar el `frontend/` como sitio estático desde otra integración (GitHub Pages, Netlify).
3. Variables de entorno: ninguna obligatoria, puedes configurar `PORT`.

## Personalización visual
- Los colores principales están en `frontend/index.html` (variables `--comi-green` y `--comi-orange`).
- Reemplaza el logo placeholder por tu logo real en la cabecera.

## Licencia
Proyecto original — código de plantilla. No copia textual del app objetivo; implementa funcionalidad de cálculo crediticio con código abierto.
